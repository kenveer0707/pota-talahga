const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('payrollAPI', {
  version: () => '1.0.0'
});
